<?php

use Illuminate\Support\Facades\Route;

Route::view('/login', 'login')->name('login');
Route::view('/create-account', 'create-account')->name('create-account');

Route::view('/', 'dashboard')->name('dashboard');
Route::view('/order-entry', 'order-entry')->name('order-entry');
Route::view('/manage-menu', 'manage-menu')->name('manage-menu');
Route::view('/inventory', 'inventory')->name('inventory');
Route::view('/sales-report', 'sales-report')->name('sales-report');
Route::view('/staff', 'staff')->name('staff');

Route::redirect('/products', '/manage-menu');

Route::view('/kitchen-queue', 'kitchen-queue')->name('kitchen-queue');
Route::view('/orders', 'orders')->name('orders');
Route::view('/recipes', 'recipes')->name('recipes');
