<?php $__env->startSection('title', 'Order Entry - Dash Coffee'); ?>
<?php $__env->startSection('main-class', 'main-flush'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $categories = [];
?>

<div class="oe">

    <section class="oe-products" data-filter-scope>
        <div class="toolbar">
            <div class="tabs" data-tabs>
                <button class="tab active" data-cat="all">All Products</button>
                <button class="tab plain" data-cat="foods">Foods</button>
                <button class="tab plain" data-cat="beverages">Beverages</button>
                <button class="tab plain" data-cat="others">Others</button>
            </div>
            <label class="search">
                <input type="search" data-search aria-label="Search products">
                <?php echo $__env->make('partials.icon', ['n' => 'search'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </label>
        </div>

        <div class="oe-scroll">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$catKey, $catTitle, $catProducts]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cat-section" data-cat="<?php echo e($catKey); ?>">
                <div class="cat-title"><span><?php echo e(strtoupper($catTitle)); ?></span><i></i></div>
                <div class="tile-grid">
                    <?php $__currentLoopData = $catProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$id, $name, $price, $img]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button class="tile" data-product data-id="<?php echo e($id); ?>" data-name="<?php echo e($name); ?>" data-price="<?php echo e($price); ?>" data-img="<?php echo e($img); ?>">
                        <span class="tile-img">
                            <?php if($img): ?>
                            <img src="<?php echo e($img); ?>" alt="">
                            <?php endif; ?>
                        </span>
                        <span class="tile-label"><b><?php echo e(strtoupper($name)); ?></b><small><?php echo e(number_format($price, 2)); ?></small></span>
                    </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <p class="empty-note" data-empty <?php echo e(count($categories) ? 'hidden' : ''); ?>>No products yet. Add them in Manage Menu.</p>
        </div>
    </section>

    <aside class="cart" id="cart">
        <div class="cart-lines" id="cart-lines"></div>

        <div class="cart-bottom">
            <div class="cart-total"><span>Total</span><strong id="cart-total">0.00</strong></div>

            <label class="field-label tiny" for="pay-method">Payment method</label>
            <div class="select-wrap">
                <select class="input input-sm" id="pay-method">
                    <option>Cash</option>
                    <option>GCash</option>
                    <option>Maya</option>
                </select>
                <?php echo $__env->make('partials.icon', ['n' => 'chevron'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <div id="cash-fields">
                <label class="field-label tiny" for="received">Amount received</label>
                <input class="input input-sm input-fill" id="received" type="number" min="0" step="0.01" placeholder="0.00">
                <div class="change-row"><span>Change</span><strong id="cart-change">0.00</strong></div>
            </div>

            <div id="ref-field" hidden>
                <label class="field-label tiny" for="reference">Reference number</label>
                <input class="input input-sm input-fill" id="reference" type="text" placeholder="1224 115 4135">
            </div>

            <div class="btn-pair">
                <button class="btn btn-red" id="clear-order" type="button">Clear Order</button>
                <button class="btn btn-green" id="confirm-order" type="button">confirm Order</button>
            </div>
        </div>
    </aside>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexa\OneDrive\Desktop\pos type shi nikker\dash-coffe\resources\views/order-entry.blade.php ENDPATH**/ ?>