<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Dash Coffee POS'); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <div class="app">

        <aside class="sidebar">
            <div class="sidebar-user">
                <span class="avatar"></span>
                <span>Owner</span>
            </div>

            <nav>
                <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">Dash board</a>
                <a href="<?php echo e(route('order-entry')); ?>" class="<?php echo e(request()->routeIs('order-entry') ? 'active' : ''); ?>">Order entry</a>
                <a href="<?php echo e(route('manage-menu')); ?>" class="<?php echo e(request()->routeIs('manage-menu') ? 'active' : ''); ?>">Manage menu</a>
                <a href="<?php echo e(route('inventory')); ?>" class="<?php echo e(request()->routeIs('inventory') ? 'active' : ''); ?>">Inventory</a>
                <a href="<?php echo e(route('sales-report')); ?>" class="<?php echo e(request()->routeIs('sales-report') ? 'active' : ''); ?>">Sales report</a>
                <a href="<?php echo e(route('staff')); ?>" class="<?php echo e(request()->routeIs('staff') ? 'active' : ''); ?>">Staff</a>
            </nav>

            <a href="<?php echo e(route('login')); ?>" class="logout">Log out</a>
        </aside>

        <main class="main <?php echo $__env->yieldContent('main-class'); ?>">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

    </div>

    <?php echo $__env->yieldPushContent('modals'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\alexa\OneDrive\Desktop\pos type shi nikker\dash-coffe\resources\views/layouts/app.blade.php ENDPATH**/ ?>