<?php $__env->startSection('title', 'Sales Report - Dash Coffee'); ?>

<?php $__env->startSection('content'); ?>
<?php
    // MySQL: total sales for the selected period
    $salesTotal = 0;
    // MySQL: number of orders for the selected period
    $orderCount = 0;
    // MySQL: graph data [label, amount], e.g. ['9 AM', 120.00] (hours for Today, days for week/month, months for year)
    $chart = [];
    $chartMax = max(array_merge([0], array_column($chart, 1)));
    // MySQL: orders keyed by order no: ['time', 'method', 'received' (Cash), 'ref' (GCash/Maya), 'lines' => [[qty, name, price]], 'total']
    $orders = [];
?>

<div class="sr">

    <div class="sr-left">
        
        <div class="tabs">
            <button class="tab active">Today</button>
            <button class="tab">This week</button>
            <button class="tab">This month</button>
            <button class="tab">This year</button>
        </div>

        <input class="input custom-date" type="text" placeholder="CUSTOM DATE" onfocus="this.type='date'" onblur="if(!this.value)this.type='text'">

        <div class="stat-row">
            <div class="panel stat">
                <span class="stat-label">SALES</span>
                <span class="stat-value"><?php echo e(number_format($salesTotal, 2)); ?></span>
            </div>
            <div class="panel stat">
                <span class="stat-label">ORDERS</span>
                <span class="stat-value"><?php echo e($orderCount); ?></span>
            </div>
        </div>

        <div class="panel chart-panel">
            <div class="chart-head">
                <span class="stat-label">SALES GRAPH</span>
                <span class="chart-sub">Amount per period</span>
            </div>

            <?php if($chartMax > 0): ?>
            <div class="bar-chart">
                <?php $__currentLoopData = $chart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $amount]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bar-col" title="<?php echo e($label); ?>: <?php echo e(number_format($amount, 2)); ?>">
                    <div class="bar-track"><span class="bar" data-value="<?php echo e(number_format($amount, 0)); ?>" style="height: <?php echo e(round($amount / $chartMax * 100)); ?>%"></span></div>
                    <span class="bar-label"><?php echo e($label); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
            <div class="chart-empty">No sales data yet.</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="panel orders-panel">
        <h2 class="list-title">TODAY'S ORDER</h2>
        <div class="order-list">
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="order-row">
                <div>
                    <b>#<?php echo e($no); ?></b>
                    <small><?php echo e($o['time']); ?> - <?php echo e(strtoupper($o['method'])); ?></small>
                </div>
                <span class="order-amount"><?php echo e(fmod($o['total'], 1) == 0 ? number_format($o['total'], 0) : number_format($o['total'], 2)); ?></span>
                <button class="icon-btn" type="button" data-order="<?php echo e($no); ?>" aria-label="View order <?php echo e($no); ?>"><?php echo $__env->make('partials.icon', ['n' => 'receipt'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty-row">No orders yet.</p>
            <?php endif; ?>
        </div>

        <button class="btn btn-green btn-block" type="button">View all orders</button>
        <button class="btn btn-green btn-block" type="button" onclick="window.print()">PRINT REPORT</button>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
<div class="modal-backdrop" id="order-modal" hidden>
    <div class="modal" role="dialog" aria-labelledby="order-title">
        <button class="modal-x" type="button" data-close-modal aria-label="Close"><?php echo $__env->make('partials.icon', ['n' => 'close'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
        <h2 class="modal-title" id="order-title"></h2>
        <p class="modal-sub" id="order-sub"></p>
        <div class="receipt" id="order-lines"></div>
        <div class="receipt-total"><span>Total</span><span id="order-total"></span></div>
        <div class="btn-row btn-row-center">
            <button class="btn btn-red btn-sm" type="button" data-open-void>Void order</button>
            <button class="btn btn-green btn-sm" type="button" onclick="window.print()">Print</button>
        </div>
    </div>
</div>

<div class="modal-backdrop" id="void-modal" hidden>
    <div class="modal" role="dialog" aria-labelledby="void-title">
        <h2 class="modal-title" id="void-title"></h2>
        <p class="modal-sub" id="void-sub"></p>
        <label class="field-label tiny" for="void-reason">void reason (required to void)</label>
        <input class="input input-sm" id="void-reason" type="text" placeholder="Wrong item">
        <div class="btn-row btn-row-center">
            
            <button class="btn btn-red btn-sm" type="button" data-close-modal>cancel</button>
            <button class="btn btn-green btn-sm" type="button" data-close-modal>Void order</button>
        </div>
    </div>
</div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    window.DASH_ORDERS = <?php echo json_encode($orders, 15, 512) ?>;
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexa\OneDrive\Desktop\pos type shi nikker\dash-coffe\resources\views/sales-report.blade.php ENDPATH**/ ?>