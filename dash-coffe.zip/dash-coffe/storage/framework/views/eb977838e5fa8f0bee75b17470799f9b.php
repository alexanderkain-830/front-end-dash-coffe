<?php
    $logoFile = 'logo-default.svg';
    foreach (['svg', 'webp', 'jpeg', 'jpg', 'png'] as $ext) {
        if (file_exists(public_path('img/logo.' . $ext))) {
            $logoFile = 'logo.' . $ext;
        }
    }
?>
<img class="<?php echo e($class); ?>" src="<?php echo e(asset('img/' . $logoFile)); ?>" alt="Dash Coffee">
<?php /**PATH C:\Users\alexa\OneDrive\Desktop\pos type shi nikker\dash-coffe\resources\views/partials/logo.blade.php ENDPATH**/ ?>