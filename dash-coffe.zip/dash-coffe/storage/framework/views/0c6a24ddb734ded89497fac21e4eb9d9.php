<?php $__env->startSection('title', 'Dashboard - Dash Coffee'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $salesTotal = 0;
    $orderCount = 0;

    $monthlyPoints = '';

    $split = [['GCash', 0, '#5b3fc4'], ['Maya', 0, '#4bb34f'], ['Cash', 0, '#111']];
    $splitTotal = array_sum(array_column($split, 1));

    $recent = [];
?>

<div class="dash">
    <?php echo $__env->make('partials.logo', ['class' => 'dash-logo'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="tabs">
        <button class="tab active">Today</button>
        <button class="tab">This week</button>
        <button class="tab">This month</button>
        <button class="tab">This year</button>
    </div>

    <div class="stat-row">
        <div class="panel stat">
            <span class="stat-label">SALES</span>
            <span class="stat-value"><?php echo e(number_format($salesTotal, 2)); ?></span>
        </div>
        <div class="panel stat">
            <span class="stat-label">ORDERS</span>
            <span class="stat-value"><?php echo e($orderCount); ?></span>
        </div>
    </div>

    <div class="panel chart-card">
        <span class="stat-label">MONTHLY SALES</span>
        <svg viewBox="0 0 400 70" preserveAspectRatio="none" class="line-chart" aria-label="Monthly sales">
            <?php if($monthlyPoints): ?>
            <defs><linearGradient id="area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#46b049" stop-opacity=".25"/><stop offset="1" stop-color="#46b049" stop-opacity="0"/></linearGradient></defs>
            <polygon fill="url(#area)" points="<?php echo e($monthlyPoints); ?> 400,70 0,70"/>
            <polyline fill="none" stroke="#2f7d32" stroke-width="1.5" vector-effect="non-scaling-stroke" points="<?php echo e($monthlyPoints); ?>"/>
            <?php else: ?>
            <line x1="0" y1="62" x2="400" y2="62" stroke="#ddd" stroke-width="1" vector-effect="non-scaling-stroke"/>
            <?php endif; ?>
        </svg>
    </div>

    <div class="panel split-card">
        <span class="stat-label">PAYMENT SPLIT</span>
        <div class="split-bar">
            <?php if($splitTotal > 0): ?>
            <?php $__currentLoopData = $split; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$method, $amount, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span style="width:<?php echo e(round($amount / $splitTotal * 100)); ?>%; background:<?php echo e($color); ?>"></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <span style="width:100%; background:#ddd"></span>
            <?php endif; ?>
        </div>
        <div class="split-labels">
            <?php $__currentLoopData = $split; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$method, $amount, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span style="width:<?php echo e($splitTotal > 0 ? round($amount / $splitTotal * 100) : 33); ?>%"><?php echo e($method); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="dash-bottom">
        <div class="panel">
            <div class="card-head"><span class="stat-label">Recent orders</span></div>
            <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$no, $time, $method, $amount]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mini-row"><span>#<?php echo e($no); ?> - <?php echo e($time); ?> - <?php echo e($method); ?></span><span><?php echo e($amount); ?></span></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty-row">No orders yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexa\OneDrive\Desktop\pos type shi nikker\dash-coffe\resources\views/dashboard.blade.php ENDPATH**/ ?>