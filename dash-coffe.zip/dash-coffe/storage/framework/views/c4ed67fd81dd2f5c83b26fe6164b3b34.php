<?php $__env->startSection('title', 'Staff - Dash Coffee'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $staff = [];
?>

<div class="mm">
    <div class="toolbar toolbar-wide">
        <h2 class="panel-title no-margin">Staff</h2>
        <div class="toolbar-right">
            <label class="search">
                <input type="search" aria-label="Search staff">
                <?php echo $__env->make('partials.icon', ['n' => 'search'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </label>
            <a href="<?php echo e(route('create-account')); ?>" class="btn btn-green btn-sm">+ ADD STAFF</a>
        </div>
    </div>

    <div class="table staff-table">
        <div class="table-head staff-cols"><span>#</span><span>Name</span><span>Username</span><span>Role</span><span>Action</span></div>
        <?php $__empty_1 = true; $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$name, $user, $role]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="table-row staff-cols">
            <span class="num"><?php echo e($i + 1); ?></span><span><?php echo e($name); ?></span><span><?php echo e($user); ?></span><span><?php echo e($role); ?></span>
            <button class="icon-btn" type="button" aria-label="Edit <?php echo e($name); ?>"><?php echo $__env->make('partials.icon', ['n' => 'pencil'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="empty-row">No staff accounts yet.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexa\OneDrive\Desktop\pos type shi nikker\dash-coffe\resources\views/staff.blade.php ENDPATH**/ ?>