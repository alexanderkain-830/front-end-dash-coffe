<?php $__env->startSection('title', 'Manage Menu - Dash Coffee'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $products = [];

    $ingredients = [];

    $ingredientOptions = [];
?>

<div class="mm" data-filter-scope>

    <div class="toolbar toolbar-wide">
        <div class="tabs" data-tabs>
            <button class="tab active" data-cat="all">All Products</button>
            <button class="tab plain" data-cat="foods">Foods</button>
            <button class="tab plain" data-cat="beverages">Beverages</button>
            <button class="tab plain" data-cat="others">Others</button>
        </div>
        <div class="toolbar-right">
            <label class="search">
                <input type="search" data-search aria-label="Search products">
                <?php echo $__env->make('partials.icon', ['n' => 'search'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </label>
            <button class="btn btn-green btn-sm" type="button">+ ADD PRODUCT</button>
        </div>
    </div>

    <div class="mm-body">

        <section class="panel mm-list">
            <h2 class="panel-title">Products</h2>
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name, $price, $img, $cat]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="list-item" data-cat="<?php echo e($cat); ?>" data-text="<?php echo e(strtolower($name)); ?>">
                <span class="thumb">
                    <?php if($img): ?>
                    <img src="<?php echo e($img); ?>" alt="">
                    <?php endif; ?>
                </span>
                <span class="list-item-text"><b><?php echo e(strtoupper($name)); ?></b><small><?php echo e(number_format($price, 2)); ?></small></span>
                <button class="btn btn-green btn-xs" type="button">EDIT</button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty-row">No products yet.</p>
            <?php endif; ?>
        </section>

        <section class="panel mm-form">
            <div class="mm-form-top">
                <div class="mm-image">
                    <span class="thumb thumb-lg"></span>
                    <button class="btn btn-outline btn-xs" type="button">Change Image</button>
                    <div class="status-toggle">
                        <span>Status</span>
                        <label class="switch"><input type="checkbox" checked><i></i></label>
                        <small>Available</small>
                    </div>
                </div>
                <div class="mm-fields">
                    <label class="field-label tiny" for="p-name">Product name</label>
                    <input class="input input-sm" id="p-name" type="text">
                    <label class="field-label tiny" for="p-cat">Category</label>
                    <div class="select-wrap">
                        <select class="input input-sm" id="p-cat"><option></option><option>Foods</option><option>Beverages</option><option>Others</option></select>
                        <?php echo $__env->make('partials.icon', ['n' => 'chevron'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                    <label class="field-label tiny" for="p-price">Price</label>
                    <input class="input input-sm" id="p-price" type="text">
                </div>
            </div>

            <div class="section-head">
                <h2>INGREDIENT</h2>
                <button class="btn btn-green btn-xs" type="button" data-open-modal="ingredient-modal"><?php echo $__env->make('partials.icon', ['n' => 'plus'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> Add Ingredient</button>
            </div>

            <div class="table">
                <div class="table-head mm-cols"><span>#</span><span>Ingredient</span><span>Unit</span><span>Quantity</span><span>Action</span></div>
                <?php $__empty_1 = true; $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$name, $unit, $qty]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="table-row mm-cols">
                    <span class="num"><?php echo e($i + 1); ?></span><span><?php echo e($name); ?></span><span><?php echo e($unit); ?></span><span><?php echo e($qty); ?></span>
                    <button class="icon-btn" type="button" aria-label="Edit <?php echo e($name); ?>"><?php echo $__env->make('partials.icon', ['n' => 'pencil'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="empty-row">No ingredients added yet.</p>
                <?php endif; ?>
            </div>

            <div class="btn-row">
                <button class="btn btn-red btn-sm" type="button">CANCEL</button>
                <button class="btn btn-green btn-sm" type="button">SAVE</button>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
<div class="modal-backdrop" id="ingredient-modal" hidden>
    <div class="modal modal-sm" role="dialog" aria-labelledby="ing-title">
        <button class="modal-x" type="button" data-close-modal aria-label="Close"><?php echo $__env->make('partials.icon', ['n' => 'close'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
        <h2 class="modal-title" id="ing-title">ADD Ingredient</h2>

        <label class="field-label tiny" for="m-ing">Ingredient</label>
        <div class="select-wrap">
            <select class="input input-sm" id="m-ing">
                <option></option>
                <?php $__currentLoopData = $ingredientOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option><?php echo e($opt); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php echo $__env->make('partials.icon', ['n' => 'chevron'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <label class="field-label tiny" for="m-unit">Unit</label>
        <div class="select-wrap"><select class="input input-sm" id="m-unit"><option></option><option>pcs</option><option>g</option><option>kg</option><option>ml</option><option>L</option></select><?php echo $__env->make('partials.icon', ['n' => 'chevron'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
        <label class="field-label tiny" for="m-qty">Quantity</label>
        <input class="input input-sm" id="m-qty" type="text">

        <div class="btn-row btn-row-center">
            <button class="btn btn-red btn-sm" type="button" data-close-modal>Cancel</button>
            <button class="btn btn-green btn-sm" type="button" data-close-modal>Save</button>
        </div>
    </div>
</div>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexa\OneDrive\Desktop\pos type shi nikker\dash-coffe\resources\views/manage-menu.blade.php ENDPATH**/ ?>