<?php $__env->startSection('title', 'Inventory - Dash Coffee'); ?>

<?php $__env->startSection('content'); ?>
<?php
    // MySQL: ingredients [name, unit, quantity, is low (true|false), category (foods|beverages|others)]
    $items = [];

    // MySQL: how many ingredients are low or getting low
    $lowCount = 0;

?>

<div class="inv" data-filter-scope>

    <section class="inv-main">
        <div class="toolbar">
            <label class="search search-wide">
                <input type="search" data-search aria-label="Search ingredients">
                <?php echo $__env->make('partials.icon', ['n' => 'search'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </label>
            <button class="btn btn-green btn-sm" type="button" data-low-toggle><?php echo $__env->make('partials.icon', ['n' => 'filter'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> LOW STOCK ONLY</button>
        </div>

        <div class="tabs" data-tabs>
            <button class="tab active" data-cat="all">All Products</button>
            <button class="tab plain" data-cat="foods">Foods</button>
            <button class="tab plain" data-cat="beverages">Beverages</button>
            <button class="tab plain" data-cat="others">Others</button>
        </div>

        <div class="table inv-table">
            <div class="table-head inv-cols"><span>#</span><span>Ingredient</span><span>Unit</span><span>Quantity</span><span>Action</span></div>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => [$name, $unit, $qty, $low, $cat]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="table-row inv-cols" data-cat="<?php echo e($cat); ?>" data-low="<?php echo e($low ? '1' : '0'); ?>" data-text="<?php echo e(strtolower($name)); ?>">
                <span class="num"><?php echo e($i + 1); ?></span><span><?php echo e($name); ?></span><span><?php echo e($unit); ?></span><span><?php echo e($qty); ?></span>
                <button class="icon-btn" type="button" data-pick="<?php echo e($name); ?>|<?php echo e($qty); ?> <?php echo e($unit); ?>|<?php echo e(ucfirst(rtrim($cat, 's'))); ?>" aria-label="Update <?php echo e($name); ?>"><?php echo $__env->make('partials.icon', ['n' => 'pencil'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></button>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty-row">No ingredients yet. Add one using the form on the right.</p>
            <?php endif; ?>
        </div>

        <?php if($lowCount > 0): ?>
        <div class="alert-bar"><?php echo $__env->make('partials.icon', ['n' => 'warn'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <span><?php echo e($lowCount); ?> <?php echo e($lowCount == 1 ? 'ingredient' : 'ingredients'); ?> running low on stock</span></div>
        <?php endif; ?>
    </section>

    <section class="panel side-card">
        <h2 class="side-title">Update stock</h2>
        <div class="chip" id="stock-chip"><b>No ingredient selected</b><small>Click a pencil in the table</small></div>
        <label class="field-label tiny" for="stock-qty">Quantity (pcs)</label>
        <input class="input qty-input" id="stock-qty" type="number" step="0.1" placeholder="0.0">
        <div class="btn-pair soft">
            <button class="btn btn-soft" type="button">+ ADD</button>
            <button class="btn btn-soft" type="button">- DEDUCT</button>
        </div>
        <div class="btn-row btn-row-center side-bottom">
            <button class="btn btn-red btn-sm" type="button">Cancel</button>
            <button class="btn btn-green btn-sm" type="button">Save</button>
        </div>
    </section>

    <section class="panel side-card">
        <h2 class="side-title">ADD Ingredient</h2>
        <label class="field-label tiny" for="n-name">Ingredient name</label>
        <input class="input input-sm" id="n-name" type="text">
        <label class="field-label tiny" for="n-unit">Unit</label>
        <div class="select-wrap"><select class="input input-sm" id="n-unit"><option></option><option>pcs</option><option>g</option><option>kg</option><option>ml</option><option>L</option></select><?php echo $__env->make('partials.icon', ['n' => 'chevron'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
        <label class="field-label tiny" for="n-init">Initial stock</label>
        <input class="input input-sm" id="n-init" type="text">
        <label class="field-label tiny" for="n-low">Low stock levels</label>
        <input class="input input-sm" id="n-low" type="text">
        <div class="btn-row btn-row-center side-bottom">
            <button class="btn btn-red btn-sm" type="button">Cancel</button>
            <button class="btn btn-green btn-sm" type="button">Save</button>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alexa\OneDrive\Desktop\pos type shi nikker\dash-coffe\resources\views/inventory.blade.php ENDPATH**/ ?>